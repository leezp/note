"""
Configuration settings for XLMMacroDeobfuscator
"""

SILENT = False  # Turn logging on/off globally
